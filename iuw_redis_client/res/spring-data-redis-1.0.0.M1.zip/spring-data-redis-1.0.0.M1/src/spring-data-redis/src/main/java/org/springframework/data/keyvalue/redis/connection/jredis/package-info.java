/**
 * Connection package for <a href="http://github.com/alphazero/jredis">JRedis</a> library.
 */
package org.springframework.data.keyvalue.redis.connection.jredis;

